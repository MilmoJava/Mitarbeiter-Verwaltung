module Projekt_MitarbeiterVerwaltung {
	requires javafx.base;
	requires javafx.graphics;
	requires java.sql;
	requires javafx.controls;
	requires org.controlsfx.controls;
	requires javafx.fxml;
	requires java.desktop;
	exports mitarbeiterVerwaltung;
}